// src/controllers/home.controller.js
export const mostrarHome = (req, res) => {
    res.render('home/index');
};
