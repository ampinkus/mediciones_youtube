/**
 * @module controllers/graficosYoutubeController
 * @description Controlador que maneja:
 * - La visualización del formulario para generar gráficos.
 * - El procesamiento de filtros de fecha, hora y stream para consultas.
 * - La organización de los datos de medición para ser enviados al gráfico.
 * - La renderización de gráficos usando los datos agrupados por stream.
 */


import sequelize from '../database/database.js';
import StreamYouTube from '../models/streams_youtube.js';
import MedicionYouTube from '../models/mediciones_youtube.js';
import { Op } from 'sequelize';
import moment from 'moment';

/**
 * Muestra el formulario donde el usuario elige un stream y un rango temporal
 * para generar **gráficos** de vistas.
 *
 * @function mostrarFormulario
 * @async
 *
 * @param {Express.Request}  req - Objeto de solicitud HTTP de Express.  
 *   - **No incluye parámetros específicos** (`req.query`, `req.body` y `req.params`
 *     están vacíos). El controlador sólo lo usa para verificar que la ruta se llamó.
 *
 * @param {Express.Response} res - Objeto de respuesta HTTP de Express.  
 *   - **Renderiza**: `'youtube/formularioGraficosYoutube'`.  
 *   - **Contexto enviado a la vista** (`locals`):  
 *     - `streams` (Array\<StreamYouTube>): lista de streams ordenada
 *       alfabéticamente por `nombre_stream`, utilizada para poblar el
 *       `<select>` del formulario.
 *
 * @returns {Promise<void>}
 */
export const mostrarFormulario = async (req, res) => {
  const streams = await StreamYouTube.findAll({
    order: [['nombre_stream', 'ASC']]
  });

  // Renderiza el formulario con la lista de streams ordenados alfabéticamente
  res.render('youtube/formularioGraficosYoutube', { streams });
};

/**
 * Procesa la solicitud proveniente del formulario de gráficos y arma los
 * **datasets** que usará la vista para dibujar los chart.js / ApexCharts.
 *
 * @function generarGrafico
 * @async
 *
 * @param {Express.Request}  req - Objeto de solicitud HTTP de Express.  
 *   Parámetros recibidos en **`req.query`**:  
 *   - `streamId`    {string|string[]} ID o array de IDs de los streams a consultar.  
 *   - `fechaInicio` {string} Fecha de inicio del período (formato DD/MM/YYYY).  
 *   - `fechaFin`    {string} Fecha de fin del período (formato DD/MM/YYYY).  
 *   - `horaInicio`  {string} Hora de inicio (HH:mm).  
 *   - `horaFin`     {string} Hora de fin (HH:mm).
 *
 * @param {Express.Response} res - Objeto de respuesta HTTP de Express.  
 *   **Renderiza** la vista `'youtube/graficosYoutube'` con el contexto:  
 *   - `datosPorStream` (Array\<object>): lista de objetos  
 *     `{ labels, data, concurrent_viewers, nombreStream, streamId }`
 *     lista que la plantilla usa para generar los diferentes gráficos.
 *
 * @returns {Promise<void>}
 */
export const generarGrafico = async (req, res) => {
  const { streamId, fechaInicio, fechaFin, horaInicio, horaFin } = req.query;

  let condiciones = {};

  // Convierte las fechas desde formato DD/MM/YYYY a objetos Date
  const fechaInicioDate = fechaInicio ? moment(fechaInicio, 'DD/MM/YYYY').toDate() : null;
  const fechaFinDate = fechaFin ? moment(fechaFin, 'DD/MM/YYYY').toDate() : null;

  // Condición: uno o varios streams
  if (streamId) {
    condiciones.streamId = { [Op.in]: Array.isArray(streamId) ? streamId : [streamId] };
  }

  // Condición: por fecha
  if (fechaInicioDate && fechaFinDate) {
    condiciones.fecha = { [Op.between]: [fechaInicioDate, fechaFinDate] };
  } else if (fechaInicioDate) {
    condiciones.fecha = { [Op.gte]: fechaInicioDate };
  } else if (fechaFinDate) {
    condiciones.fecha = { [Op.lte]: fechaFinDate };
  }

  // Condición: por hora
  if (horaInicio && horaFin) {
    condiciones.hora_medicion = { [Op.between]: [horaInicio, horaFin] };
  } else if (horaInicio) {
    condiciones.hora_medicion = { [Op.gte]: horaInicio };
  } else if (horaFin) {
    condiciones.hora_medicion = { [Op.lte]: horaFin };
  }

  // Busca las mediciones en base a las condiciones definidas
  const mediciones = await MedicionYouTube.findAll({
    where: condiciones,
    include: { model: StreamYouTube },
    order: [['fecha', 'ASC'], ['hora_medicion', 'ASC']]
  });

  const datosPorStream = [];
  const streamsUnicos = [...new Set(mediciones.map(m => m.streamId))];

  for (const id of streamsUnicos) {
    // Filtra las mediciones correspondientes a cada stream
    const datosFiltrados = mediciones.filter(m => m.streamId === id);

    // Construye las etiquetas para el eje X a partir de fecha y hora
    const labels = datosFiltrados.map(m => {
      const [hh, mm] = m.hora_medicion.split(':');
      const [yyyy, mm1, dd] = m.fecha.split('-');
      return new Date(yyyy, mm1 - 1, dd, hh, mm);
    });

    // Extrae los datos de view_count (vistas totales) y concurrent_viewers
    const data = datosFiltrados.map(m => m.view_count);
    const concurrent_viewers = datosFiltrados.map(m => m.concurrent_viewers);

    // Obtiene el nombre del stream
    const nombreStream = datosFiltrados.length > 0 ? datosFiltrados[0].StreamYouTube.nombre_stream : 'Sin datos';

    // Agrega los datos organizados al array final
    datosPorStream.push({ labels, data, concurrent_viewers, nombreStream, streamId: id });
  }

  // Renderiza la vista con los datos de los gráficos
  res.render('youtube/graficosYoutube', { datosPorStream });
};
